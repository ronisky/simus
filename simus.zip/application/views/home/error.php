<div class="container">
    <div class="row">
        <div class="col-md-12 text-center mb-5">
            <h3 class="mt-5 mb-2">Maaf, halaman yang Anda minta tidak ditemukan</h3><br>
            <p> <a href="<?= base_url() ?>" class="btn btn-primary btn-sm">Kembali ke Home</a> </p>
        </div>
    </div>
</div>